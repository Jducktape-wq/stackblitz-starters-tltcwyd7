
"use client";
import React, { useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer, CartesianGrid, BarChart, Bar } from "recharts";

function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const EUROPEAN = Array.from({ length: 37 }, (_, i) => i);
const AMERICAN = [...EUROPEAN, 37];
const RED = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
const colorOf = (n, american) => (n===0 || (american && n===37)) ? "green" : (RED.has(n) ? "red" : "black");

function spin(rng, american){ const arr = american ? AMERICAN : EUROPEAN; return { n: arr[Math.floor(rng()*arr.length)] }; }
function isWin(type, out, params, american){
  const n = out.n, c = colorOf(n, american);
  switch(type){
    case "even": return n!==0 && n!==37 && n%2===0;
    case "odd":  return n!==0 && n!==37 && n%2===1;
    case "red":  return c==="red";
    case "black":return c==="black";
    case "dozen1": return n>=1 && n<=12;
    case "dozen2": return n>=13 && n<=24;
    case "dozen3": return n>=25 && n<=36;
    case "straight": return n===params.straightNumber;
    default: return false;
  }
}
const payout = (type) => (type==="straight"?35:(["dozen1","dozen2","dozen3"].includes(type)?2:1));

function nextBet(strategy, base, last, state, maxBet){
  const cap = x => Math.max(0, Math.min(x, maxBet));
  switch(strategy){
    case "Flat": return cap(base);
    case "Martingale": { const lastStake = state.lastStake ?? base; const stake = last==="loss" ? lastStake*2 : base; state.lastStake = stake; return cap(stake); }
    case "DAlembert": { let u = state.u ?? 1; if (last==="loss") u+=1; if (last==="win") u=Math.max(1,u-1); state.u=u; return cap(base*u); }
    case "Fibonacci": { let i = state.i ?? 1; const fib=n=>{let a=1,b=1;for(let k=2;k<=n;k++){[a,b]=[b,a+b]}return b}; if(last==="loss") i+=1; if(last==="win") i=Math.max(1,i-2); state.i=i; return cap(base*fib(i)); }
    case "Paroli": { let s = state.streak ?? 0; if (last==="win") s+=1; else if (last==="loss") s=0; state.streak=s; return cap(base*Math.pow(2, Math.min(s,2))); }
    case "Random": { const x=Math.random(); return cap(base*(x<0.33?1:x<0.66?2:3)); }
    default: return cap(base);
  }
}

function simulate(p){
  const {american, betType, straightNumber, strategy, spins, runs, initialBankroll, baseBet, maxBet, stopLoss, takeProfit, seed} = p;
  const results = [];
  for(let r=0;r<runs;r++){
    const rng = (seed!=null)? mulberry32((seed+r)|0) : Math.random;
    let bank = initialBankroll, eq=[bank], ruin=false, peak=bank, maxDD=0, last=null, st={};
    for(let s=0;s<spins;s++){
      if (stopLoss!=null && bank<=stopLoss) break;
      if (takeProfit!=null && bank>=takeProfit) break;
      if (bank<=0){ ruin=true; break; }
      const stake = Math.min(nextBet(strategy, baseBet, last, st, maxBet), bank);
      if (stake<=0) break;
      const outcome = spin(rng, american);
      const win = isWin(betType, outcome, {straightNumber}, american);
      const m = payout(betType);
      if (win) bank += stake*m; else bank -= stake;
      last = win? "win":"loss";
      peak = Math.max(peak, bank); maxDD = Math.max(maxDD, peak-bank);
      eq.push(bank);
    }
    results.push({ finalBankroll: bank, equity: eq, ruin, maxDrawdown: maxDD });
  }
  const finals = results.map(r=>r.finalBankroll);
  const mean = finals.reduce((a,b)=>a+b,0)/Math.max(1,finals.length);
  const sorted=[...finals].sort((a,b)=>a-b); const median=sorted[Math.floor(sorted.length/2)]??0;
  const stdev=Math.sqrt(finals.reduce((acc,x)=>acc+Math.pow(x-mean,2),0)/Math.max(1,finals.length));
  const ruinProb=results.filter(r=>r.ruin||r.finalBankroll<=0).length/Math.max(1,results.length);
  const profitProb=results.filter(r=>r.finalBankroll>p.initialBankroll).length/Math.max(1,results.length);
  const avgMaxDD=results.reduce((a,r)=>a+r.maxDrawdown,0)/Math.max(1,results.length);
  return { results, stats:{ mean, median, stdev, ruinProb, profitProb, avgMaxDD } };
}

function makeHist(data, bins=20){
  if (!data.length) return [];
  const min = Math.min(...data), max = Math.max(...data);
  const width = (max-min)/(bins||1) || 1;
  const counts = Array.from({length: bins}, ()=>0);
  data.forEach(x=>{ const i=Math.min(bins-1, Math.max(0, Math.floor((x-min)/width))); counts[i]+=1; });
  return counts.map((c,i)=>({bin:String(Math.round(min+i*width)), count:c}));
}

function downloadCSV(rows, filename="results.csv"){
  const esc = (cell)=>`"${String(cell).replace(/"/g,'""')}"`;
  const content = rows.map(r=>r.map(esc).join(",")).join("\\n");
  const blob = new Blob([content], {type:"text/csv;charset=utf-8;"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=filename; a.click();
}

export default function Page(){
  const [american, setAmerican] = useState(false);
  const [betType, setBetType] = useState("red");
  const [straightNumber, setStraightNumber] = useState(17);
  const [strategy, setStrategy] = useState("Flat");
  const [spins, setSpins] = useState(200);
  const [runs, setRuns] = useState(200);
  const [initialBankroll, setInitialBankroll] = useState(1000);
  const [baseBet, setBaseBet] = useState(10);
  const [maxBet, setMaxBet] = useState(500);
  const [stopLoss, setStopLoss] = useState(null);
  const [takeProfit, setTakeProfit] = useState(null);
  const [seed, setSeed] = useState(12345);
  const [sim, setSim] = useState(null);

  const run = ()=> setSim(simulate({ american, betType, straightNumber, strategy, spins, runs, initialBankroll, baseBet, maxBet, stopLoss, takeProfit, seed }));

  const exampleEquity = useMemo(()=> sim? (sim.results[0]?.equity||[]).map((v,i)=>({spin:i,bankroll:v})) : [], [sim]);
  const finals = useMemo(()=> sim? sim.results.map(r=>r.finalBankroll):[], [sim]);
  const hist = useMemo(()=> makeHist(finals, 24), [finals]);

  const exportSummary = ()=>{
    if(!sim) return;
    const rows=[["Run","Final Bankroll","Ruin","Max Drawdown","Wheel","Bet Type","Straight Number","Strategy","Spins","Runs","Initial Bankroll","Base Bet","Max Bet","Stop-Loss","Take-Profit","Seed"]];
    sim.results.forEach((r,i)=>rows.push([i+1, r.finalBankroll.toFixed(2), r.ruin?"Yes":"No", r.maxDrawdown.toFixed(2), american?"American":"European", betType, straightNumber, strategy, spins, runs, initialBankroll, baseBet, maxBet, stopLoss??"", takeProfit??"", seed??""]));
    downloadCSV(rows, "roulette_results.csv");
  };
  const exportEquity = ()=>{
    if(!sim) return;
    const rows=[["Run","Spin","Bankroll"]];
    sim.results.forEach((r,ri)=> r.equity.forEach((b,si)=> rows.push([ri+1, si, b.toFixed(2)])));
    downloadCSV(rows, "roulette_equity_long.csv");
  };

  const applyTemplate = (id)=>{
    if(id===1){ setStrategy("Flat"); setBaseBet(10); setInitialBankroll(1000); setMaxBet(500); setBetType("red"); setSpins(200); setRuns(200); }
    if(id===2){ setStrategy("Martingale"); setBaseBet(10); setInitialBankroll(1000); setMaxBet(500); setBetType("red"); setSpins(200); setRuns(200); }
    if(id===3){ setStrategy("DAlembert"); setBaseBet(20); setInitialBankroll(1000); setMaxBet(500); setBetType("red"); setSpins(200); setRuns(200); }
    if(id===4){ setStrategy("Fibonacci"); setBaseBet(20); setInitialBankroll(1000); setMaxBet(500); setBetType("red"); setSpins(200); setRuns(200); }
    if(id===5){ setStrategy("Paroli"); setBaseBet(50); setInitialBankroll(1000); setMaxBet(500); setBetType("red"); setSpins(200); setRuns(200); }
  };

  return (
    <div style={{maxWidth:1000, margin:"20px auto", padding:"16px"}}>
      <h1 style={{fontSize:28, marginBottom:12}}>Roulette Strategy Simulator</h1>

      <div style={{display:"grid", gridTemplateColumns:"repeat(3,minmax(0,1fr))", gap:12}}>
        <div><label>Wheel<br/>
          <select value={american? "american":"european"} onChange={e=>setAmerican(e.target.value==="american")}>
            <option value="european">European (0)</option>
            <option value="american">American (0,00)</option>
          </select></label></div>

        <div><label>Bet Type<br/>
          <select value={betType} onChange={e=>setBetType(e.target.value)}>
            <option value="red">Red (1:1)</option><option value="black">Black (1:1)</option>
            <option value="even">Even (1:1)</option><option value="odd">Odd (1:1)</option>
            <option value="dozen1">1st Dozen (2:1)</option><option value="dozen2">2nd Dozen (2:1)</option><option value="dozen3">3rd Dozen (2:1)</option>
            <option value="straight">Straight (35:1)</option>
          </select></label>
          {betType==="straight" && (<div style={{marginTop:6}}><label>Number <input type="number" value={straightNumber} min={0} max={american?37:36} onChange={e=>setStraightNumber(parseInt(e.target.value||"0"))}/></label></div>)}
        </div>

        <div><label>Strategy<br/>
          <select value={strategy} onChange={e=>setStrategy(e.target.value)}>
            <option value="Flat">Flat</option><option value="Martingale">Martingale</option>
            <option value="DAlembert">D'Alembert</option><option value="Fibonacci">Fibonacci</option>
            <option value="Paroli">Paroli</option><option value="Random">Random</option>
          </select></label></div>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"repeat(3,minmax(0,1fr))", gap:12, marginTop:12}}>
        <label>Spins per Run<br/><input type="number" value={spins} onChange={e=>setSpins(parseInt(e.target.value||"0"))}/></label>
        <label>Runs<br/><input type="number" value={runs} onChange={e=>setRuns(parseInt(e.target.value||"0"))}/></label>
        <label>Initial Bankroll<br/><input type="number" value={initialBankroll} onChange={e=>setInitialBankroll(parseFloat(e.target.value||"0"))}/></label>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"repeat(3,minmax(0,1fr))", gap:12, marginTop:12}}>
        <label>Base Bet<br/><input type="number" value={baseBet} onChange={e=>setBaseBet(parseFloat(e.target.value||"0"))}/></label>
        <label>Max Bet Cap<br/><input type="number" value={maxBet} onChange={e=>setMaxBet(parseFloat(e.target.value||"0"))}/></label>
        <label>Seed (optional)<br/><input type="number" value={seed??""} onChange={e=>setSeed(e.target.value===""?null:parseInt(e.target.value))}/></label>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"repeat(2,minmax(0,1fr))", gap:12, marginTop:12}}>
        <label>Stop-Loss (bankroll)<br/><input type="number" value={stopLoss??""} onChange={e=>setStopLoss(e.target.value===""?null:parseFloat(e.target.value))}/></label>
        <label>Take-Profit (bankroll)<br/><input type="number" value={takeProfit??""} onChange={e=>setTakeProfit(e.target.value===""?null:parseFloat(e.target.value))}/></label>
      </div>

      <div style={{display:"flex", gap:8, marginTop:12}}>
        <button onClick={run}>Run Simulation</button>
        <button onClick={()=>setSim(null)}>Reset</button>
        <button onClick={exportSummary} disabled={!sim}>Export Summary CSV</button>
        <button onClick={exportEquity} disabled={!sim}>Export Equity (Long)</button>
      </div>

      <div style={{marginTop:12}}>
        <div>Quick Templates:</div>
        <div style={{display:"flex", gap:6, flexWrap:"wrap", marginTop:6}}>
          <button onClick={()=>applyTemplate(1)}>1. Flat</button>
          <button onClick={()=>applyTemplate(2)}>2. Martingale</button>
          <button onClick={()=>applyTemplate(3)}>3. D'Alembert</button>
          <button onClick={()=>applyTemplate(4)}>4. Fibonacci</button>
          <button onClick={()=>applyTemplate(5)}>5. Paroli</button>
        </div>
      </div>

      {sim && (
        <div style={{display:"grid", gridTemplateColumns:"2fr 1fr", gap:12, marginTop:16}}>
          <div style={{height:320, border:"1px solid #eee", borderRadius:12, padding:8}}>
            <div style={{fontWeight:600, marginBottom:4}}>Sample Run: Bankroll Over Spins</div>
            <ResponsiveContainer width="100%" height="90%">
              <LineChart data={exampleEquity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="spin" /><YAxis /><RTooltip />
                <Line type="monotone" dataKey="bankroll" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div style={{height:320, border:"1px solid #eee", borderRadius:12, padding:8}}>
            <div style={{fontWeight:600, marginBottom:4}}>Final Bankroll Distribution</div>
            <ResponsiveContainer width="100%" height="90%">
              <BarChart data={hist}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="bin" /><YAxis /><RTooltip /><Bar dataKey="count" /></BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {sim && (
        <div style={{marginTop:12, border:"1px solid #eee", borderRadius:12, padding:12, display:"grid", gridTemplateColumns:"repeat(6, minmax(0,1fr))", gap:8}}>
          <div><div style={{color:"#666", fontSize:12}}>Mean Final</div><div style={{fontWeight:600}}>{sim.stats.mean.toFixed(2)}</div></div>
          <div><div style={{color:"#666", fontSize:12}}>Median Final</div><div style={{fontWeight:600}}>{sim.stats.median.toFixed(2)}</div></div>
          <div><div style={{color:"#666", fontSize:12}}>Std Dev</div><div style={{fontWeight:600}}>{sim.stats.stdev.toFixed(2)}</div></div>
          <div><div style={{color:"#666", fontSize:12}}>P(Profit)</div><div style={{fontWeight:600}}>{(sim.stats.profitProb*100).toFixed(1)}%</div></div>
          <div><div style={{color:"#666", fontSize:12}}>P(Ruin)</div><div style={{fontWeight:600}}>{(sim.stats.ruinProb*100).toFixed(1)}%</div></div>
          <div><div style={{color:"#666", fontSize:12}}>Avg Max Drawdown</div><div style={{fontWeight:600}}>{sim.stats.avgMaxDD.toFixed(2)}</div></div>
        </div>
      )}
    </div>
  );
}
